#1 模型合并
from peft import AutoPeftModelForCausalLM
path_to_adapter=r"C:\Users\gbqqw\Desktop\test\Qwen-main\Qwen-main\output_qwen\output_qwen"
new_model_directory=r"C:\Users\gbqqw\Desktop\test\Qwen-main\Qwen-main\Qwen-1_8B-Chat_law"
model = AutoPeftModelForCausalLM.from_pretrained(
 path_to_adapter, # path to the output directory
 device_map="auto",
 trust_remote_code=True
).eval()
merged_model = model.merge_and_unload()
merged_model.save_pretrained(new_model_directory, max_shard_size="2048MB",
safe_serialization=True)
#2 分词器保存
from transformers import AutoTokenizer
tokenizer = AutoTokenizer.from_pretrained(
 path_to_adapter, # path to the output directory
 trust_remote_code=True
)
tokenizer.save_pretrained(new_model_directory)