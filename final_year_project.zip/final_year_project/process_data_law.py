import json

# 确保 json_data 和 template 都被正确初始化
json_data = []
template = []

# 使用 try-except 来处理文件读写中的潜在错误r
try:
    # 打开 .jsonl 文件并逐行读取
    with open(r"/home/coder/github/Qwen/DISC-Law-SFT/DISC-Law-SFT-Triplet-released.jsonl", 'r', encoding='utf-8') as file:
        for line in file:
            # 将每一行的 JSON 数据加载到 json_data 列表中
            data = json.loads(line)
            json_data.append(data)  # 修正数据读取位置

    # 遍历 json_data 数据集，构建模板
    for idx, data in enumerate(json_data):
        conversation = [
            {
                "from": "user",
                "value": data.get("input", "")  # 使用 .get() 方法，避免缺少键时报错
            },
            {
                "from": "assistant",
                "value": data.get("output", "")  # 同样使用 .get()
            }
        ]
        template.append({
            "id": f"identity_{idx}",
            "conversations": conversation
        })  # 将会话追加到模板中

    # 输出模板的大小，检查生成的数据
    print(len(template))

    # 检查模板的样本数据
    if len(template) > 2:
        print(json.dumps(template[2], ensure_ascii=False, indent=2))

    # 将模板写入到本地文件，使用 try-except 确保文件写入无误
    output_file_path = "train_data_law.json"
    with open(output_file_path, 'w', encoding='utf-8') as f:
        json.dump(template, f, ensure_ascii=False, indent=2)
    print(f"处理好的数据已写入到本地文件: {output_file_path}")

except FileNotFoundError:
    print("错误：找不到指定的文件路径。请检查文件路径是否正确。")
except json.JSONDecodeError:
    print("错误：读取 JSON 数据失败。请确保文件格式正确。")
except Exception as e:
    print(f"发生意外错误: {e}")
