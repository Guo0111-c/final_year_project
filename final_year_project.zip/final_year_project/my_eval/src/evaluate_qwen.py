import argparse
import os
from functools import partial

import torch
import pandas as pd
from transformers import AutoModelForCausalLM, AutoTokenizer, GenerationConfig
from ml3m.base import ResponseGenerator
from tabulate import tabulate

from eval import McqRegexEvaluator, QaOpenaiEvaluator
from utils import colored, generate_and_evaluate, get_paths, print_section


DEFAULT_CKPT_PATH = "/media/seagate-1/ass/xiao_er_di/test/Qwen-main/Qwen-main/Qwen-1_8B-Chat_law"

def _load_model_tokenizer(checkpoint_path="../../Qwen-1_8B-Chat_law", cpu_only=False):
    os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"
    tokenizer = AutoTokenizer.from_pretrained(checkpoint_path, trust_remote_code=True)
    device_map = "cpu" if cpu_only else "auto"
    model = AutoModelForCausalLM.from_pretrained(
        checkpoint_path,
        device_map=device_map,
        torch_dtype=torch.float16,
        trust_remote_code=True
    ).eval()
    config = GenerationConfig.from_pretrained(checkpoint_path, trust_remote_code=True)
    if not hasattr(config, "pad_token_id") or config.pad_token_id is None:
        config.pad_token_id = tokenizer.pad_token_id or tokenizer.eos_token_id
    model.config.pad_token_id = config.pad_token_id
    config.max_new_tokens = 512
    config.max_length = 2048
    return model, tokenizer, config



def qwen_chat_fn(model, tokenizer, config):
    def chat(query, history=None):
        history = history or []
        output = model.chat(tokenizer, query, history=history, generation_config=config)
        if isinstance(output, tuple):
            output = output[0]  # Extract actual response string
        return output
    return chat


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Evaluate Qwen-7B Model")
    parser.add_argument("--tasks", choices=["mcq_sing", "mcq_mult", "qa"], nargs="+", required=True)
    parser.add_argument("--n-shot", type=int, default=4)
    parser.add_argument("--max-iter", type=int, default=5)
    parser.add_argument("--verbose", type=int, default=1)
    parser.add_argument("--eval-only", action="store_true")
    parser.add_argument("--generate-only", action="store_true")
    parser.add_argument("--cpu-only", action="store_true")
    parser.add_argument("--unique-dir", action="store_true")
    parser.add_argument("--checkpoint-path", type=str, default=DEFAULT_CKPT_PATH)
    args = parser.parse_args()

    assert not (args.generate_only and args.eval_only)

    model, tokenizer, config = _load_model_tokenizer(args.checkpoint_path, args.cpu_only)
    chat_fn = qwen_chat_fn(model, tokenizer, config)
    model_name = "qwen"

    dirname = os.path.dirname(__file__)
    basedir = os.path.join(dirname, "..")
    openai_config = os.path.join(basedir, "..", "openai.json")

    def mcq_info_func(data_item, multi):
        question, A, B, C, D = data_item[["input", "A", "B", "C", "D"]]
        options_repr = "\n".join([f"{label}. {option}" for label, option in zip("ABCD", [A, B, C, D])])
        prompt = f"{question}\n{options_repr}\n你的答案是：" if not multi else f"{question}\n{options_repr}\n请选择所有正确的选项："
        return prompt

    def qa_info_func(data_item):
        question = data_item["input"]
        return f"请回答以下问题：{question}"

    mcq_sing_scores = {}
    if "mcq_sing" in args.tasks:
        mcq_sing_dataset_names = ["cpa", "lbk", "nje", "pae", "pfe", "ungee"]
        for dataset_name in mcq_sing_dataset_names:
            orig_dataset, dataset, save_path = get_paths(
                basedir, "objective/mcq_sing", "csv", dataset_name, model_name, args.unique_dir
            )
            mcq_sing_scores[dataset_name] = generate_and_evaluate(
                task_name="MCQ::sing",
                dataset_name=dataset_name,
                generator_klass=ResponseGenerator,
                generator_kwargs=dict(
                    orig_dataset=orig_dataset,
                    dataset=dataset,
                    info_func=partial(mcq_info_func, multi=False),
                    query_func=chat_fn,
                    response_name=f"{model_name}_response",
                    fmt="csv",
                    n_workers=1,
                    verbose=args.verbose,
                ),
                evaluator_klasses=[McqRegexEvaluator],
                evaluator_kwargses=[dict(
                    dataset=dataset,
                    save_path=save_path,
                    subjects=["regex_score"],
                    response_name=f"{model_name}_response",
                    verbose=args.verbose,
                )],
                max_iter=args.max_iter,
                eval_only=args.eval_only,
                generate_only=args.generate_only,
            )

    mcq_mult_scores = {}
    if "mcq_mult" in args.tasks:
        mcq_mult_dataset_names = ["cpa", "nje", "pae", "ungee"]
        for dataset_name in mcq_mult_dataset_names:
            orig_dataset, dataset, save_path = get_paths(
                basedir, "objective/mcq_mult", "csv", dataset_name, model_name, args.unique_dir
            )
            mcq_mult_scores[dataset_name] = generate_and_evaluate(
                task_name="MCQ::mult",
                dataset_name=dataset_name,
                generator_klass=ResponseGenerator,
                generator_kwargs=dict(
                    orig_dataset=orig_dataset,
                    dataset=dataset,
                    info_func=partial(mcq_info_func, multi=True),
                    query_func=chat_fn,
                    response_name=f"{model_name}_response",
                    fmt="csv",
                    n_workers=1,
                    verbose=args.verbose,
                ),
                evaluator_klasses=[McqRegexEvaluator],
                evaluator_kwargses=[dict(
                    dataset=dataset,
                    save_path=save_path,
                    subjects=["regex_score"],
                    response_name=f"{model_name}_response",
                    verbose=args.verbose,
                )],
                max_iter=args.max_iter,
                eval_only=args.eval_only,
                generate_only=args.generate_only,
            )

    qa_scores = {}
    if "qa" in args.tasks:
        qa_dataset_names = ["short_answer"]
        for dataset_name in qa_dataset_names:
            orig_dataset, dataset, save_path = get_paths(
                basedir, "subjective/qa", "json", dataset_name, model_name, args.unique_dir
            )
            qa_scores[dataset_name] = generate_and_evaluate(
                task_name="QA",
                dataset_name=dataset_name,
                generator_klass=ResponseGenerator,
                generator_kwargs=dict(
                    orig_dataset=orig_dataset,
                    dataset=dataset,
                    info_func=qa_info_func,
                    query_func=chat_fn,
                    response_name=f"{model_name}_response",
                    fmt="json",
                    n_workers=1,
                    verbose=args.verbose,
                ),
                evaluator_klasses=[QaOpenaiEvaluator],
                evaluator_kwargses=[dict(
                    dataset=dataset,
                    save_path=save_path,
                    openai_config=openai_config,
                    info_func=lambda data_item: (
                        data_item["input"],
                        data_item[f"{model_name}_response"],
                        data_item["output"],
                    ),
                    fmt="json",
                    verbose=args.verbose,
                )],
                max_iter=args.max_iter,
                eval_only=args.eval_only,
                generate_only=args.generate_only,
            )

    for name, scores in zip(["MCQ::sing", "MCQ::mult", "QA"], [mcq_sing_scores, mcq_mult_scores, qa_scores]):
        if len(scores) == 0:
            continue
        df = pd.DataFrame(scores).T
        df.loc[colored("AVG", "green"), :] = df.mean()
        print_section(f"[{name}] EVALUATION SUMMARY", "green")
        print(tabulate(df, headers="keys", tablefmt="fancy_outline"))
