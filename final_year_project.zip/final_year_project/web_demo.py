import os
from argparse import ArgumentParser

import gradio as gr
import mdtex2html

import torch
import faiss
import numpy as np
from transformers import AutoModelForCausalLM, AutoTokenizer, GenerationConfig
from sentence_transformers import SentenceTransformer
from docx import Document as DocxDocument
import fitz  # PyMuPDF

# DEFAULT_CKPT_PATH = 'Qwen/Qwen-7B-Chat'
DEFAULT_CKPT_PATH = 'Qwen-1_8B-Chat_law'
# DEFAULT_CKPT_PATH = 'Qwen-1_8B-Chat'
# DOCUMENT_DIR = './empty/'
DOCUMENT_DIR = './rag_docs'


def _get_args():
    parser = ArgumentParser()
    parser.add_argument("-c", "--checkpoint-path", type=str, default=DEFAULT_CKPT_PATH)
    parser.add_argument("--cpu-only", action="store_true")
    parser.add_argument("--share", action="store_true", default=False)
    parser.add_argument("--inbrowser", action="store_true", default=False)
    parser.add_argument("--server-port", type=int, default=8000)
    parser.add_argument("--server-name", type=str, default="0.0.0.0")
    return parser.parse_args()


def _load_model_tokenizer(args):
    os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"
    tokenizer = AutoTokenizer.from_pretrained(
        args.checkpoint_path, trust_remote_code=True
    )
    device_map = "cpu" if args.cpu_only else "auto"
    model = AutoModelForCausalLM.from_pretrained(
        args.checkpoint_path,
        device_map=device_map,
        torch_dtype=torch.float16,
        trust_remote_code=True
    ).eval()
    config = GenerationConfig.from_pretrained(
        args.checkpoint_path, trust_remote_code=True
    )
    if not hasattr(config, "pad_token_id") or config.pad_token_id is None:
        config.pad_token_id = tokenizer.pad_token_id or tokenizer.eos_token_id
    model.config.pad_token_id = config.pad_token_id
    config.max_new_tokens = 512
    config.max_length = 2048
    return model, tokenizer, config


def extract_text_from_pdf(path):
    doc = fitz.open(path)
    return "\n".join(page.get_text() for page in doc)


def extract_text_from_docx(path):
    doc = DocxDocument(path)
    return "\n".join(para.text for para in doc.paragraphs)


def _load_rag_documents():
    documents = []
    for fname in os.listdir(DOCUMENT_DIR):
        path = os.path.join(DOCUMENT_DIR, fname)
        if fname.endswith('.txt'):
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read()
        elif fname.endswith('.pdf'):
            content = extract_text_from_pdf(path)
        elif fname.endswith('.docx'):
            content = extract_text_from_docx(path)
        else:
            continue

        # Split by paragraphs and strip
        chunks = [p.strip() for p in content.split("\n") if p.strip()]
        documents.extend(chunks)

    return documents, None


def _build_faiss_index(documents):
    if not documents:
        print("⚠️ No documents found. Skipping RAG index.")
        return None, None, None
    embedding_model = SentenceTransformer("intfloat/multilingual-e5-large")
    embeddings = embedding_model.encode(documents, show_progress_bar=True, normalize_embeddings=True)
    if embeddings.shape[0] == 0:
        print("⚠️ Empty embeddings.")
        return None, None, None
    index = faiss.IndexFlatIP(embeddings.shape[1])
    index.add(np.array(embeddings))
    return index, embedding_model, np.array(embeddings)

# rest of your code (unchanged) continues below...


def postprocess(self, y):
    if y is None:
        return []
    for i, (message, response) in enumerate(y):
        y[i] = (
            None if message is None else mdtex2html.convert(message),
            None if response is None else mdtex2html.convert(response),
        )
    return y

gr.Chatbot.postprocess = postprocess

def _parse_text(text):
    lines = text.split("\n")
    lines = [line for line in lines if line != ""]
    count = 0
    for i, line in enumerate(lines):
        if "```" in line:
            count += 1
            items = line.split("`")
            lines[i] = f'<pre><code class="language-{items[-1]}">' if count % 2 == 1 else "<br></code></pre>"
        else:
            if i > 0 and count % 2 == 1:
                line = line.replace("`", r"\`")
                line = line.replace("<", "&lt;")
                line = line.replace(">", "&gt;")
                line = line.replace(" ", "&nbsp;")
                line = line.replace("*", "&ast;")
                line = line.replace("_", "&lowbar;")
                line = line.replace("-", "&#45;")
                line = line.replace(".", "&#46;")
                line = line.replace("!", "&#33;")
                line = line.replace("(", "&#40;")
                line = line.replace(")", "&#41;")
                line = line.replace("$", "&#36;")
            lines[i] = "<br>" + line
    return "".join(lines)

def _gc():
    import gc
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

def _launch_demo(args, model, tokenizer, config, documents, index, embedding_model):

    def predict(_query, _chatbot, _task_history):
        print(f"User: {_parse_text(_query)}")

        if index and embedding_model and documents:
            query_embedding = embedding_model.encode([_query])
            k = 3  # more context improves accuracy
            _, top_k_indices = index.search(query_embedding, k=k)
            retrieved_context = "\n".join([documents[i] for i in top_k_indices[0]])

            context_intro = "请根据以下资料回答问题：\n"
            question_prompt = f"\n\n问题：{_query}"

            context_tokens = tokenizer.tokenize(context_intro + retrieved_context)
            question_tokens = tokenizer.tokenize(question_prompt)

            max_total_tokens = 1280
            max_context_tokens = max_total_tokens - len(question_tokens)
            if len(context_tokens) > max_context_tokens:
                context_tokens = context_tokens[:max_context_tokens]

            final_tokens = context_tokens + question_tokens
            final_prompt = tokenizer.convert_tokens_to_string(final_tokens)
        else:
            final_prompt = _query

        _chatbot.append((_parse_text(_query), ""))
        full_response = ""

        for response in model.chat_stream(tokenizer, final_prompt, history=_task_history, generation_config=config):
            _chatbot[-1] = (_parse_text(_query), _parse_text(response))
            yield _chatbot
            full_response = _parse_text(response)

        _task_history.append((_query, full_response))
        torch.cuda.empty_cache()

    def regenerate(_chatbot, _task_history):
        if not _task_history:
            yield _chatbot
            return
        item = _task_history.pop(-1)
        _chatbot.pop(-1)
        yield from predict(item[0], _chatbot, _task_history)

    def reset_user_input():
        return gr.update(value="")

    def reset_state(_chatbot, _task_history):
        _task_history.clear()
        _chatbot.clear()
        _gc()
        return _chatbot

    with gr.Blocks() as demo:
        gr.Markdown("<center><h1>🤖 Qwen-Chat with RAG (优化准确率 & 支持中文/PDF/DOCX)</h1></center>")

        chatbot = gr.Chatbot(label='Qwen-RAG Chatbot')
        query = gr.Textbox(lines=2, label='请输入你的问题')
        task_history = gr.State([])

        with gr.Row():
            clear_btn = gr.Button("🧹 清除历史")
            send_btn = gr.Button("🚀 发送")
            retry_btn = gr.Button("🔄 重试")

        send_btn.click(predict, [query, chatbot, task_history], [chatbot], show_progress=True)
        send_btn.click(reset_user_input, [], [query])
        clear_btn.click(reset_state, [chatbot, task_history], outputs=[chatbot], show_progress=True)
        retry_btn.click(regenerate, [chatbot, task_history], [chatbot], show_progress=True)

    demo.queue().launch(
        share=args.share,
        inbrowser=args.inbrowser,
        server_port=args.server_port,
        server_name=args.server_name,
    )

def main():
    args = _get_args()
    model, tokenizer, config = _load_model_tokenizer(args)
    documents, _ = _load_rag_documents()
    index, embedding_model, _ = _build_faiss_index(documents)

    if index is None:
        documents = []
        embedding_model = None

    _launch_demo(args, model, tokenizer, config, documents, index, embedding_model)

if __name__ == '__main__':
    main()